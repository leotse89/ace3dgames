bbpress-starter-theme-v2.0
==========================

This is a blank starter theme for bbPress to get an invision or phpBB feel - it will need customising to match your site. 



EpicWebs.co.uk Post: http://www.epicwebs.co.uk/bbpress-tutorials/bbpress-starter-theme/


bbPress Topic: http://bbpress.org/forums/topic/i-have-created-a-bbpress-starter-theme-with-a-phpbb-look-and-feel/
